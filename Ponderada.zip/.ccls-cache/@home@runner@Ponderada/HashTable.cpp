#include "HashTable.h"
#include <iostream>

HashTable::HashTable() {}

int HashTable::getHash(int codigo) {
    return codigo % MAX_ITEMS;
}

void HashTable::insertItem(Produto produto) {
    int index = getHash(produto.getCodigo());
    items[index].push_back(produto);
}

void HashTable::deleteItem(int codigo) {
    int index = getHash(codigo);
    items[index].remove_if([codigo](const Produto& p) { return p.getCodigo() == codigo; });
}

void HashTable::print() const {
    for (int i = 0; i < MAX_ITEMS; i++) {
        if (!items[i].empty()) {
            std::cout << "Posição " << i << ": ";
            for (const auto& produto : items[i]) {
                std::cout << "Código: " << produto.getCodigo() << ", Descrição: " << produto.getDescricao()
                          << ", Preço: R$" << produto.getPreco() << " | ";
            }
            std::cout << std::endl;
        }
    }
}

bool HashTable::findItem(int codigo) {
    int index = getHash(codigo);
    for (const auto& item : items[index]) {
        if (item.getCodigo() == codigo) {
            return true;  
        }
    }
    return false;  
}

