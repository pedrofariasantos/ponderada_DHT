#ifndef PRODUTO_H
#define PRODUTO_H

#include <string>

class Produto {
public:
    int codigo;
    std::string descricao;
    float preco; 

    Produto(); 
    Produto(int cod, std::string desc, float preco); 
    int getCodigo() const; 
    std::string getDescricao() const; 
    float getPreco() const; 
};

#endif