#ifndef HASHTABLE_H
#define HASHTABLE_H

#include "Produto.h"
#include <list>

const int MAX_ITEMS = 100;

class HashTable {
private:
    std::list<Produto> items[MAX_ITEMS];
    int getHash(int codigo); 

public:
    HashTable();
    void insertItem(Produto produto);
    void deleteItem(int codigo);
    void print() const;
    bool findItem(int codigo); 
};

#endif