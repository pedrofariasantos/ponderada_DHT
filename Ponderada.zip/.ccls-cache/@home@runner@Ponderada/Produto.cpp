#include "Produto.h"

Produto::Produto() : codigo(-1), descricao(""), preco(0.0) {}

Produto::Produto(int cod, std::string desc, float preco) : codigo(cod), descricao(desc), preco(preco) {}

int Produto::getCodigo() const {
    return codigo;
}

std::string Produto::getDescricao() const {
    return descricao;
}

float Produto::getPreco() const {
    return preco;
}