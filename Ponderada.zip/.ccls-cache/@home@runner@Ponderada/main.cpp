#include <iostream>
#include <cassert>
#include "Produto.h"
#include "HashTable.h"


void runTests() {
    std::cout << "Iniciando os testes..." << std::endl;


    Produto p1(1, "Caneta Azul", 1.50);
    Produto p2(2, "Lápis Grafite", 0.75);
    Produto p3(3, "Borracha Branca", 0.50); 
    Produto p4(1, "Caneta Vermelha", 1.75); 

    HashTable tabela;


    std::cout << "\nTeste 1: Inserção de Itens\n";
    tabela.insertItem(p1);
    tabela.insertItem(p2);
    tabela.insertItem(p3); 
    std::cout << "Após inserir Caneta Azul, Lápis Grafite e Borracha Branca:" << std::endl;
    tabela.print();


    std::cout << "\nTeste 2: Tratamento de Colisões\n";
    tabela.insertItem(p4); 
    std::cout << "Após inserir Caneta Vermelha (mesmo código que Caneta Azul):" << std::endl;
    tabela.print();


    std::cout << "\nTeste 3: Remoção de Itens\n";
    tabela.deleteItem(1); 
    std::cout << "Após remover produtos com código 1 (Canetas):" << std::endl;
    tabela.print();

  std::cout << "\nTeste 4: Busca de Itens\n";
  tabela.insertItem(Produto(100, "Produto Especial", 999.99)); 
  bool found = tabela.findItem(100); 
  std::cout << "Busca por Produto Especial (deve ser encontrado): " << (found ? "Sucesso" : "Falha") << std::endl;

  tabela.deleteItem(100); 
  found = tabela.findItem(100); 
  std::cout << "Busca por Produto Especial após remoção (não deve ser encontrado): " << (found ? "Falha" : "Sucesso") << std::endl;


  std::cout << "\nTeste 5: Testando a capacidade\n";
  for (int i = 101; i <= MAX_ITEMS; i++) { 
      tabela.insertItem(Produto(i, "Produto " + std::to_string(i), i * 1.1));
  }
  std::cout << "Tabela após tentar exceder a capacidade:" << std::endl;
  tabela.print();
}


int main() {

    runTests();

    HashTable tabela;
    Produto p1(1, "Caneta Azul", 1.50);
    Produto p2(2, "Lápis Grafite", 0.75);
    Produto p3(3, "Borracha Branca", 0.50);

    tabela.insertItem(p1);
    tabela.insertItem(p2);
    tabela.insertItem(p3);



    return 0;
}
